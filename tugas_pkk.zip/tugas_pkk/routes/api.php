<?php

use App\Http\Controllers\Admin\AdminController;
use App\Http\Controllers\Auth\AuthController;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Route;

Route::get('/user', function (Request $request) {
    return $request->user();
})->middleware('auth:sanctum');

Route::group([
    'prefix' => 'auth'
], function() {
    Route::post('/register', [AuthController::class, 'register']);
    Route::post('/login', [AuthController::class, 'login']);
    Route::post('/logout', [AuthController::class, 'logout'])->middleware('auth:sanctum');
});

Route::group([
    'prefix' => 'admin',
    'middleware' => 'auth:sanctum'
], function() {
    //class
    Route::post('/class', [AdminController::class, 'StoreClass']);
    Route::get('/class', [AdminController::class, 'ShowClass']);
    Route::put('/class/{id}', [AdminController::class, 'UpdateClass']);
    Route::delete('/class/{id}', [AdminController::class, 'DestroyClass']);

    //subject
});
