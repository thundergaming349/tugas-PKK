<?php

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\StudentClass;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class AdminController extends Controller
{
    public function StoreClass(Request $request) {
        $user = $request->user();

        if($user->role !== 'admin') {
            return response()->json([
                'message' => 'Forbidden Access'
            ], 403);
        }

        $validated = Validator::make($request->all(), [
            'name' => 'required'
        ]);

        if($validated->fails()) {
            return response()->json([
                'message' => 'Invalid field'
            ], 422);
        }

        StudentClass::create($validated->validated());
        return response()->json([
            'message' => 'class created'
        ], 201);
    }

    public function UpdateClass(Request $request, $id) {
        $user = $request->user();

        if($user->role !== 'admin') {
            return response()->json([
                'message' => 'Forbidden Access'
            ], 403);
        }

        $class = StudentClass::find($id);
        if(!$class) {
            return response()->json([
                'message' => 'Class not found'
            ], 404);
        }

        $validated = Validator::make($request->all(), [
            'name' => 'required'
        ]);

        if($validated->fails()) {
            return response()->json([
                'message' => 'Invalid field'
            ], 422);
        }

        $class->update($validated->validated());
        return response()->json([
            'message' => 'Class modifed'
        ]);
    }

    public function DestroyClass(Request $request, $id) {
        $user = $request->user();

        if($user->role !== 'admin') {
            return response()->json([
                'message' => 'Forbidden Access'
            ], 403);
        }

        $class = StudentClass::find($id);
        if(!$class) {
            return response()->json([
                'message' => 'Class not found'
            ], 404);
        }

        StudentClass::destroy($id);
        return response()->json('', 204);
    }

    public function ShowClass(Request $request) {
        $user = $request->user();

        if($user->role !== 'admin') {
            return response()->json([
                'message' => 'Forbidden Access'
            ], 403);
        }

        $query = StudentClass::get();
        return response()->json([
            'class' => $query
        ]);

    }
}
