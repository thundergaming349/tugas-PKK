<?php

namespace App\Http\Controllers;

use App\Models\Session;
use App\Models\Subject;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;
use SessionIdInterface;

class SessionController extends Controller
{
    public function store(Request $request)
    {
        $user = $request->user();

        if ($user->role !== 'guru') {
            return response()->json([
                'message' => 'Kamu bukan guru'
            ], 422);
        }

        $subId = $user->Subject()->get('id');

        $subject_id = [];
        foreach ($subId as $id) {
            $subject_id[] = $id->id;
        }


        $validated = Validator::make($request->all(), [
            'class_id' => 'required|int|exists:student_classes,id',
            'subject_id' => 'required|int|exists:subjects,id',
            'date' => 'required|date_format:Y-m-d',
            'start' => 'required|date_format:H:i',
            'end' => 'required|date_format:H:i'
        ], [
            'class_id.exists' => "class ID doesn't exists",
            'subject_id' => "subject ID doesn't exists"
        ]);

        if ($validated->fails()) {
            return response()->json([
                'message' => 'Invalid field',
                'errors' => $validated->errors()
            ], 422);
        }

        $subject = Subject::find($request['subject_id']);
        if ($subject->teacher_id !== $user->id) {
            return response()->json([
                'message' => 'Forbidden access'
            ], 422);
        }

        $collapse = Session::whereIn('subject_id', $subject_id)->where('date', $request['date'])
            ->where('start', '<', $request['end'])->where('end', '>', $request['start'])->exists();
        if ($collapse) {
            return response()->json([
                'message' => 'Guru ada jadwal lain yang bertabrakan',
                'type' => 'conflict'
            ], 422);
        }

        Session::create($validated->validated());
        return response()->json([
            'message' => 'session created'
        ], 201);
    }

    public function update(Request $request, int $id) {
        $user = $request->user();

        if ($user->role !== 'guru') {
            return response()->json([
                'message' => 'Kamu bukan guru'
            ], 422);
        }

        $session = Session::find($id); 
        if(!$session) {
            return response()->json([
                'message' => 'session not found'
            ], 404);
        }

        $subId = $user->Subject()->get('id');

        $subject_id = [];
        foreach ($subId as $ids) {
            $subject_id[] = $ids->id;
        }

        $validated = Validator::make($request->all(), [
            'date' => 'required|date_format:Y-m-d',
            'start' => 'required|date_format:H:i:s',
            'end' => 'required|date_format:H:i:s'
        ]);

        if ($validated->fails()) {
            return response()->json([
                'message' => 'Invalid field',
                'errors' => $validated->errors()
            ], 422);
        }

        $collapse = Session::whereNot('id', $id)->whereIn('subject_id', $subject_id)->where('date', $request['date'])
            ->where('start', '<', $request['end'])->where('end', '>', $request['start'])->exists();
        if ($collapse) {
            return response()->json([
                'message' => 'Guru ada jadwal lain yang bertabrakan',
                'type' => 'conflict'
            ], 422);
        }

        $session->update($validated->validated());
        return response()->json([
            'message' => 'session modified'
        ]);
    }

    public function show(Request $request) {
        $user = $request->user();

        if ($user->role !== 'guru') {
            return response()->json([
                'message' => 'Kamu bukan guru'
            ], 422);
        }

        $subId = $user->Subject()->get('id');

        $subject_id = [];
        foreach ($subId as $id) {
            $subject_id[] = $id->id;
        }

        $query = Session::query()->with('Subject', 'StudentClass')->whereHas('Subject', function($q) use ($subject_id) {
            $q->whereIn('subject_id', $subject_id);
        })->join('student_classes', 'student_classes.id', '=', 'sessions.class_id')->get();

        return response()->json([
            'session' => $query->map(function($q) {
                return [
                    'id' => $q->id,
                    'class_id' => $q->class_id,
                    'class_name' => $q->name,
                    'subject_id' => $q->subject->id,
                    'subject_name' => $q->subject->name,
                    'date' => $q->date,
                    'start' => substr($q->start, 0, 5),
                    'end' => substr($q->end, 0, 5),
                    'hidden' => $q->hidden
                ];
            })
        ]);
    }
}
